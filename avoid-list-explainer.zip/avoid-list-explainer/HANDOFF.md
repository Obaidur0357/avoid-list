# HANDOFF: Avoid List (Remotion মোশন গ্রাফিক্স এক্সপ্লেনার)

## ১. ভিডিও
- বিষয়: ১১টি স্বাস্থ্য-সমস্যা বনাম কী এড়াতে হবে (উচ্চ রক্তচাপ থেকে চোখের চাপ পর্যন্ত)। ভয়েসওভার ইংরেজি, প্রায় ৩০.৩ সেকেন্ড।
- মোট দৈর্ঘ্য: ৯৭৫ ফ্রেম (৩২.৫ সেকেন্ড) = ভয়েসওভার ৩০.১ সেকেন্ড + শেষে ২.৪ সেকেন্ডের রিক্যাপ গ্রিড।
- স্ক্রিনের টেক্সট ইংরেজি (ভয়েসওভার ও রেফারেন্সের সাথে মিল রাখতে; স্যান্ডবক্সে বাংলা ফন্ট ছিল না)।

## ২. ইউজারের বাছাই
- স্টাইল: Dark Tech / Medical Glow
- কালার: Medical Amber: bg `#0B0504`, hero `#FFD21F`, accent `#FF8A5B`, text `#FFFFFF`
- রেশিও: 9:16 (1080x1920), 30fps

## ৩. সিনের অবস্থা
- ১১টি টিপ সিন: শেষ (কোড লেখা)। লেআউট ক্রমে ঘোরে: Hero Stack → Split Cards → Callout।
- রিক্যাপ গ্রিড: শেষ। হেডার, ক্যাপশন, SFX, PreviewAudio: শেষ।
- আসল Remotion দিয়ে এখনো চালানো বা যাচাই হয়নি (স্যান্ডবক্সে ইন্টারনেট ছিল না)।

## ৪. অনুমান ও সন্দেহ
- সময় শুধু `public/script.srt` থেকে। cue-র ভেতর শব্দের সময় অক্ষরসংখ্যা অনুপাতে ভাগ করা (আনুমানিক)।
- ভিজ্যুয়াল কথার ৫ ফ্রেম আগে ঢোকে (`LEAD` in `src/script.ts`)।
- ফন্ট (Barlow Condensed, Inter) `@remotion/google-fonts` থেকে নামে, প্রথমবার ইন্টারনেট লাগবে।
- প্রিভিউ ছবিগুলো আসল Remotion নয়, একটি টেস্ট হার্নেসে (fallback ফন্টে) তোলা আনুমানিক ছবি। আসল ফন্ট আরও সরু হবে।
- `package.json`-এ Remotion `^4.0.0`। সব remotion প্যাকেজ একই ভার্সনে না এলে `npm i remotion@latest @remotion/cli@latest @remotion/google-fonts@latest` চালান।
- ভয়েসওভার ডিফল্টে MP4 রেন্ডারে মেশানো হয় না। মেশাতে `src/components/PreviewAudio.tsx`-এ `INCLUDE_VOICEOVER_IN_RENDER = true`।

## ৫. রেন্ডার
- ইনস্টল: `npm install`
- প্রিভিউ: `npx remotion studio src/index.ts`
- MP4: `npx remotion render src/index.ts Main out/video.mp4 --codec h264 --crf 17`
- SFX আবার বানাতে: `node scripts/make-sfx.mjs`

## ৬. পরবর্তী ধাপ
- ZIP আপলোড করে "চালিয়ে যাও" বা "রেন্ডার করো" বলুন। যাচাইয়ের জন্য Remotion চালু আছে এমন পরিবেশ লাগবে।
- কিছু বদলাতে চাইলে: সিনের লেআউট `src/components/TipScene.tsx`, রং/ফন্ট `src/theme.ts`, টেক্সট ও টাইমিং `src/script.ts`।
