// UI/মোশন-গ্রাফিক্স ধাঁচের ছোট SFX সিন্থেসাইজ করে public/sfx/ এ 16-bit WAV লেখে।
import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const SR = 44100;
const OUT = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
mkdirSync(OUT, { recursive: true });

let seed = 1234567;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return (seed / 0xffffffff) * 2 - 1;
};
const buf = (sec) => new Float32Array(Math.floor(sec * SR));

const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  for (let i = 0; i < x.length; i++) {
    y += a * (x[i] - y);
    x[i] = y;
  }
  return x;
};
const highpass = (x, fc) => {
  const lp = lowpass(Float32Array.from(x), fc);
  for (let i = 0; i < x.length; i++) x[i] -= lp[i];
  return x;
};
const reverb = (x, mix = 0.12) => {
  const delays = [0.019, 0.027, 0.037].map((d) => Math.floor(d * SR));
  const out = Float32Array.from(x);
  for (const d of delays) for (let i = d; i < x.length; i++) out[i] += x[i - d] * mix * 0.6;
  return out;
};
const fade = (x, inMs, outMs) => {
  const a = Math.floor((inMs / 1000) * SR);
  const b = Math.floor((outMs / 1000) * SR);
  for (let i = 0; i < a && i < x.length; i++) x[i] *= i / a;
  for (let i = 0; i < b && i < x.length; i++) x[x.length - 1 - i] *= i / b;
  return x;
};
const finish = (x, peak = 0.9) => {
  lowpass(x, 9500);
  x = reverb(x);
  fade(x, 2, 25);
  let m = 0;
  for (const v of x) m = Math.max(m, Math.abs(v));
  const g = m > 0 ? peak / m : 1;
  for (let i = 0; i < x.length; i++) x[i] *= g;
  return x;
};

const pop = () => {
  const x = buf(0.28);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 180 + 360 * Math.exp(-t * 28);
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, t / 0.003) * Math.exp(-t * 16);
    x[i] = (Math.sin(ph) + 0.25 * Math.sin(2 * ph)) * env;
  }
  return finish(x);
};
const click = () => {
  const x = buf(0.12);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const env = Math.exp(-t * 260);
    x[i] = rnd() * env * 0.9 + Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t * 120) * 0.35;
  }
  highpass(x, 2200);
  return finish(x);
};
const whoosh = (dur, f0, f1) => {
  const x = buf(dur);
  let low = 0,
    band = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / x.length;
    const fc = f0 * Math.pow(f1 / f0, t);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    const q = 0.35;
    const n = rnd();
    low += f * band;
    const high = n - low - q * band;
    band += f * high;
    const env = Math.sin(Math.PI * Math.pow(t, 0.7)) ** 1.5;
    x[i] = band * env;
  }
  return finish(x, 0.85);
};
const thud = () => {
  const x = buf(0.35);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (48 + 60 * Math.exp(-t * 30))) / SR;
    x[i] = Math.sin(ph) * Math.min(1, t / 0.006) * Math.exp(-t * 11);
  }
  lowpass(x, 400);
  return finish(x);
};
const chime = () => {
  const x = buf(0.5);
  const partials = [
    [880, 1.0, 9],
    [1320.8, 0.45, 12],
    [1761, 0.25, 16],
    [2640, 0.1, 22],
  ];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let s = 0;
    for (const [f, a, d] of partials) s += Math.sin(2 * Math.PI * f * t) * a * Math.exp(-t * d);
    x[i] = s * Math.min(1, t / 0.005);
  }
  return finish(x);
};

const wav = (name, x) => {
  const data = Buffer.alloc(x.length * 2);
  for (let i = 0; i < x.length; i++) data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x[i])) * 32767), i * 2);
  const h = Buffer.alloc(44);
  h.write("RIFF", 0);
  h.writeUInt32LE(36 + data.length, 4);
  h.write("WAVEfmt ", 8);
  h.writeUInt32LE(16, 16);
  h.writeUInt16LE(1, 20);
  h.writeUInt16LE(1, 22);
  h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * 2, 28);
  h.writeUInt16LE(2, 32);
  h.writeUInt16LE(16, 34);
  h.write("data", 36);
  h.writeUInt32LE(data.length, 40);
  writeFileSync(join(OUT, `${name}.wav`), Buffer.concat([h, data]));
  let pk = 0;
  for (const v of x) pk = Math.max(pk, Math.abs(v));
  console.log(`${name}.wav  ${(x.length / SR).toFixed(2)}s  peak ${pk.toFixed(2)}`);
};

wav("pop", pop());
wav("click", click());
wav("whoosh1", whoosh(0.55, 350, 3200));
wav("whoosh2", whoosh(0.48, 500, 2600));
wav("thud", thud());
wav("chime", chime());
