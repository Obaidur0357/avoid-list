// সময়ের একমাত্র উৎস: SRT (public/script.srt)। নিচের cue গুলো সেখান থেকে নেওয়া।
// শব্দ-পর্যায়ের সময় SRT-তে নেই: প্রতিটি cue-র ভেতর অক্ষরসংখ্যা অনুপাতে ভাগ করা (আনুমানিক)।

export const FPS = 30;
export const LEAD = 5; // ভিজ্যুয়াল কথার ৪-৬ ফ্রেম আগে ঢোকে
export const OVERLAP = 6; // সিনের এক্সিট/এন্ট্রি ওভারল্যাপ
export const AUDIO_SECONDS = 30.32;
export const RECAP_FRAMES = 72;

type Cue = { start: number; end: number; text: string };

export const cues: Cue[] = [
  { start: 0.16, end: 2.0, text: "High blood pressure problem: avoid too" },
  { start: 2.04, end: 4.88, text: "much salt. Acidity problem: avoid spicy" },
  { start: 4.9, end: 5.6, text: "and fried food." },
  { start: 6.24, end: 8.56, text: "Diabetes problem: avoid sugar and sweets." },
  { start: 9.24, end: 11.22, text: "Gout problem: avoid too much red meat." },
  { start: 11.82, end: 13.98, text: "Lung problem: avoid smoking. High" },
  { start: 14.06, end: 15.9, text: "cholesterol problem: avoid butter and" },
  { start: 15.92, end: 16.18, text: "ghee." },
  { start: 16.82, end: 19.38, text: "Overweight problem: avoid junk food. Tooth" },
  { start: 19.42, end: 21.5, text: "decay problem: avoid candy and chocolate." },
  { start: 22.08, end: 24.14, text: "Sleep problem: avoid tea and coffee at" },
  { start: 24.18, end: 26.72, text: "night. Kidney stone problem: avoid soft" },
  { start: 26.76, end: 29.48, text: "drinks. Eye strain problem: avoid too much" },
  { start: 29.54, end: 30.1, text: "screen time." },
];

export type Word = { text: string; norm: string; start: number; end: number };

const buildWords = (): Word[] => {
  const out: Word[] = [];
  for (const cue of cues) {
    const parts = cue.text.split(/\s+/).filter(Boolean);
    const total = parts.reduce((a, p) => a + p.length + 1, 0);
    const dur = cue.end - cue.start;
    let acc = 0;
    for (const p of parts) {
      const w = p.length + 1;
      out.push({
        text: p.replace(/[:.,]+$/, ""),
        norm: p.toLowerCase().replace(/[^a-z]/g, ""),
        start: cue.start + (acc / total) * dur,
        end: cue.start + ((acc + w) / total) * dur,
      });
      acc += w;
    }
  }
  return out;
};

export const words = buildWords();

type Def = { key: string; problem: string; avoid: string; marker: string[] };

const defs: Def[] = [
  { key: "bp", problem: "High blood pressure", avoid: "Too much salt", marker: ["high", "blood", "pressure"] },
  { key: "acidity", problem: "Acidity", avoid: "Spicy & fried food", marker: ["acidity"] },
  { key: "diabetes", problem: "Diabetes", avoid: "Sugar & sweets", marker: ["diabetes"] },
  { key: "gout", problem: "Gout", avoid: "Too much red meat", marker: ["gout"] },
  { key: "lung", problem: "Lung problem", avoid: "Smoking", marker: ["lung"] },
  { key: "cholesterol", problem: "High cholesterol", avoid: "Butter & ghee", marker: ["high", "cholesterol"] },
  { key: "weight", problem: "Overweight", avoid: "Junk food", marker: ["overweight"] },
  { key: "tooth", problem: "Tooth decay", avoid: "Candy & chocolate", marker: ["tooth", "decay"] },
  { key: "sleep", problem: "Sleep problem", avoid: "Tea & coffee at night", marker: ["sleep"] },
  { key: "kidney", problem: "Kidney stone", avoid: "Soft drinks", marker: ["kidney", "stone"] },
  { key: "eye", problem: "Eye strain", avoid: "Too much screen time", marker: ["eye", "strain"] },
];

const findSeq = (seq: string[], from: number): number => {
  for (let i = from; i <= words.length - seq.length; i++) {
    if (seq.every((s, k) => words[i + k].norm === s)) return i;
  }
  throw new Error(`SRT-তে পাওয়া যায়নি: ${seq.join(" ")}`);
};

const f = (sec: number) => Math.round(sec * FPS);

export const LAST_END_FRAME = f(words[words.length - 1].end);
export const RECAP_START = LAST_END_FRAME;
export const TOTAL_FRAMES = Math.max(Math.ceil(AUDIO_SECONDS * FPS), RECAP_START + RECAP_FRAMES);

export type Tip = {
  index: number;
  key: string;
  problem: string;
  avoid: string;
  start: number; // ফ্রেম
  duration: number; // ফ্রেম (ওভারল্যাপসহ)
  avoidAt: number; // সিনের শুরু থেকে, ফ্রেম
};

const buildTips = (): Tip[] => {
  let cursor = 0;
  const idxs = defs.map((d) => {
    const i = findSeq(d.marker, cursor);
    cursor = i + d.marker.length;
    return i;
  });
  return defs.map((d, n) => {
    const wi = idxs[n];
    const start = Math.max(0, f(words[wi].start) - LEAD);
    const next = n < defs.length - 1 ? Math.max(0, f(words[idxs[n + 1]].start) - LEAD) : LAST_END_FRAME;
    const duration = next - start + OVERLAP;
    const ai = words.findIndex((w, k) => k > wi && w.norm === "avoid");
    const rawAvoid = f(words[ai].start) - LEAD - start;
    const avoidAt = Math.min(Math.max(14, rawAvoid), duration - 26);
    return { index: n, key: d.key, problem: d.problem, avoid: d.avoid, start, duration, avoidAt };
  });
};

export const tips = buildTips();

export const currentTipIndex = (frame: number): number => {
  let idx = 0;
  tips.forEach((t, i) => {
    if (frame >= t.start) idx = i;
  });
  return idx;
};
