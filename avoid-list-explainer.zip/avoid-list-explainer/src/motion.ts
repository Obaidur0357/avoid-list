import type { CSSProperties } from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";

export const clamp = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

type SpringCfg = { damping: number; stiffness: number; mass: number };

export const useSpring = (delay = 0, config: SpringCfg = theme.spring.pop) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config });
};

export const useEase = (from: number, to: number, a = 0, b = 1) => {
  const frame = useCurrentFrame();
  return interpolate(frame, [from, to], [a, b], { ...clamp, easing: theme.ease.out });
};

// ধীর ভাসা, দুই সেকেন্ডের বেশি স্ক্রিনে থাকা এলিমেন্টের জন্য
export const useFloat = (amp = 8, hz = 0.35, phase = 0) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return Math.sin((frame / fps) * Math.PI * 2 * hz + phase) * amp;
};

export const enterStyle = (p: number, rise = 56, extraY = 0, extraScale = 1): CSSProperties => ({
  opacity: Math.max(0, Math.min(1, p * 1.8)),
  transform: `translateY(${(1 - p) * rise + extraY}px) scale(${(0.86 + 0.14 * p) * extraScale})`,
});
