import { Easing } from "remotion";
import { loadFont as loadDisplay } from "@remotion/google-fonts/BarlowCondensed";
import { loadFont as loadBody } from "@remotion/google-fonts/Inter";

// ফন্ট: প্রথমবার চালানোর সময় ইন্টারনেট লাগে (Google Fonts থেকে নামে)
const display = loadDisplay("normal", {
  weights: ["600", "700", "800"],
  subsets: ["latin"],
});
const body = loadBody("normal", { weights: ["500", "600"], subsets: ["latin"] });

export const theme = {
  colors: {
    bg: "#0B0504", // ৬০% বেস
    bgWarm: "#2A0F07",
    accent: "#FF8A5B", // ৩০% সেকেন্ডারি
    hero: "#FFD21F", // ১০% হিরো (এক ফ্রেমে একটিই এলিমেন্ট)
    text: "#FFFFFF",
    textSoft: "rgba(255,255,255,0.66)",
    glassTop: "rgba(255,190,140,0.14)",
    glassBottom: "rgba(255,255,255,0.03)",
    glassBorder: "rgba(255,255,255,0.16)",
    accentGlow: "rgba(255,138,91,0.38)",
  },
  fonts: {
    display: display.fontFamily,
    body: body.fontFamily,
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    inOut: Easing.bezier(0.65, 0, 0.35, 1),
  },
  spring: {
    pop: { damping: 13, stiffness: 170, mass: 0.7 },
    snappy: { damping: 18, stiffness: 230, mass: 0.6 },
    soft: { damping: 24, stiffness: 90, mass: 1 },
    draw: { damping: 30, stiffness: 70, mass: 1 },
  },
  layout: {
    width: 1080,
    height: 1920,
    headerY: 196,
    captionY: 1380,
  },
  radius: { card: 44, pill: 999 },
};
