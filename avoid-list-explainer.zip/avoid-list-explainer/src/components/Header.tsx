import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { clamp, useSpring } from "../motion";
import { OVERLAP, RECAP_START, currentTipIndex, tips } from "../script";
import { theme } from "../theme";

const SEG_W = 72;
const GAP = 8;

export const Header: React.FC = () => {
  const frame = useCurrentFrame();
  const idx = currentTipIndex(frame);
  const tip = tips[idx];
  const enter = useSpring(2, theme.spring.soft);
  const swap = useSpring(tip.start, theme.spring.snappy);
  const hide = interpolate(frame, [RECAP_START - 2, RECAP_START + 6], [1, 0], clamp);
  const c = theme.colors;
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top: theme.layout.headerY,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 18,
        opacity: Math.min(1, enter * 1.5) * hide,
        transform: `translateY(${(1 - enter) * -50}px)`,
      }}
    >
      <div
        style={{
          width: 11 * SEG_W + 10 * GAP,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
          fontFamily: theme.fonts.body,
          fontWeight: 600,
          fontSize: 30,
          color: c.textSoft,
        }}
      >
        <span>Avoid list</span>
        <span style={{ color: c.text, display: "inline-block", transform: `scale(${0.8 + 0.2 * swap})` }}>
          {String(idx + 1).padStart(2, "0")} / {tips.length}
        </span>
      </div>
      <div style={{ display: "flex", gap: GAP }}>
        {tips.map((t, i) => {
          const fill =
            i < idx
              ? 1
              : i === idx
              ? interpolate(frame, [t.start, t.start + t.duration - OVERLAP], [0, 1], clamp)
              : 0;
          return (
            <div
              key={t.key}
              style={{
                width: SEG_W,
                height: 8,
                borderRadius: 8,
                background: "rgba(255,255,255,0.14)",
                overflow: "hidden",
              }}
            >
              <div style={{ width: `${fill * 100}%`, height: "100%", background: c.accent }} />
            </div>
          );
        })}
      </div>
    </div>
  );
};
