import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { RECAP_START, tips } from "../script";

const SFX_LEN = 30;

type Ev = { at: number; file: string; vol: number };

// ইভেন্ট: সিন ট্রানজিশনে whoosh, নিষেধ-দাগ বসলে click, হুকে হালকা thud, রিক্যাপে pop ও chime
const events = (): Ev[] => {
  const ev: Ev[] = [{ at: 0, file: "thud", vol: 0.3 }];
  tips.forEach((t, i) => {
    if (i > 0) ev.push({ at: Math.max(0, t.start - 2), file: i % 2 ? "whoosh1" : "whoosh2", vol: 0.26 });
    ev.push({ at: t.start + t.avoidAt + 10, file: "click", vol: 0.3 });
  });
  ev.push({ at: RECAP_START - 2, file: "whoosh1", vol: 0.26 });
  ev.push({ at: RECAP_START + 4, file: "chime", vol: 0.26 });
  ev.push({ at: RECAP_START + 14, file: "pop", vol: 0.28 });
  return ev;
};

export const Sfx: React.FC = () => (
  <>
    {events().map((e, i) => (
      <Sequence key={i} from={e.at} durationInFrames={SFX_LEN}>
        <Audio src={staticFile(`sfx/${e.file}.wav`)} volume={e.vol} />
      </Sequence>
    ))}
  </>
);
