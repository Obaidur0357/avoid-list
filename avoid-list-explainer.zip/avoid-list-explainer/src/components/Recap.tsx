import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { clamp, enterStyle, useSpring } from "../motion";
import { OVERLAP, tips } from "../script";
import { theme } from "../theme";
import { Icon, Prohibit } from "./Icons";
import { Medallion } from "./Parts";

const ROWS = [3, 3, 3, 2];

const Cell: React.FC<{ i: number }> = ({ i }) => {
  const frame = useCurrentFrame();
  const tip = tips[i];
  const delay = 10 + i * 3;
  const p = useSpring(delay, theme.spring.pop);
  const ring = interpolate(frame, [delay + 8, delay + 22], [0, 1], { ...clamp, easing: theme.ease.out });
  return (
    <div style={{ width: 290, display: "flex", flexDirection: "column", alignItems: "center", gap: 12, ...enterStyle(p, 50) }}>
      <Medallion size={180}>
        <div style={{ position: "relative", width: 100, height: 100 }}>
          <Icon name={`a-${tip.key}`} size={100} color={theme.colors.text} stroke={3.4} />
          <Prohibit size={100} progress={ring} />
        </div>
      </Medallion>
      <div
        style={{
          fontFamily: theme.fonts.display,
          fontWeight: 700,
          fontSize: 40,
          lineHeight: 1,
          textAlign: "center",
          textTransform: "uppercase",
          color: theme.colors.text,
          minHeight: 80,
        }}
      >
        {tip.problem}
      </div>
    </div>
  );
};

// সমাপ্তি: চেকলিস্ট রিক্যাপ গ্রিড
export const Recap: React.FC = () => {
  const pTitle = useSpring(2, theme.spring.snappy);
  let n = 0;
  return (
    <AbsoluteFill style={{ alignItems: "center" }}>
      <div
        style={{
          position: "absolute",
          top: 230,
          fontFamily: theme.fonts.display,
          fontWeight: 800,
          fontSize: 150,
          lineHeight: 1,
          textTransform: "uppercase",
          color: theme.colors.hero,
          textShadow: "0 0 40px rgba(255,210,31,0.35)",
          ...enterStyle(pTitle, 60),
        }}
      >
        Avoid list
      </div>
      <div style={{ position: "absolute", top: 440, display: "flex", flexDirection: "column", gap: 28 }}>
        {ROWS.map((count, r) => (
          <div key={r} style={{ display: "flex", justifyContent: "center", gap: 24 }}>
            {Array.from({ length: count }).map(() => {
              const i = n++;
              return <Cell key={i} i={i} />;
            })}
          </div>
        ))}
      </div>
    </AbsoluteFill>
  );
};

export const RECAP_ENTER_OVERLAP = OVERLAP;
