import React, { useEffect, useState } from "react";
import { Audio, getRemotionEnvironment, staticFile } from "remotion";

// ফ্ল্যাগ: স্টুডিও প্রিভিউতে ভয়েসওভার বাজবে কিনা
export const PREVIEW_VOICEOVER = true;
// ফ্ল্যাগ: MP4 রেন্ডারে ভয়েসওভার মেশানো হবে কিনা (ডিফল্ট: না)
export const INCLUDE_VOICEOVER_IN_RENDER = false;

export const PreviewAudio: React.FC = () => {
  const [exists, setExists] = useState(false);
  const { isRendering } = getRemotionEnvironment();

  useEffect(() => {
    if (isRendering) return;
    let alive = true;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => alive && setExists(r.ok))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [isRendering]);

  if (!PREVIEW_VOICEOVER) return null;
  if (isRendering) return INCLUDE_VOICEOVER_IN_RENDER ? <Audio src={staticFile("voiceover.mp3")} /> : null;
  return exists ? <Audio src={staticFile("voiceover.mp3")} /> : null;
};
