import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { clamp, enterStyle, useEase, useFloat, useSpring } from "../motion";
import { OVERLAP, Tip } from "../script";
import { theme } from "../theme";
import { Icon, Prohibit } from "./Icons";
import { Medallion, avoidTextStyle, glassCard, problemTextStyle } from "./Parts";

type P = { tip: Tip };

const AvoidBadge: React.FC<{ tip: Tip; size: number }> = ({ tip, size }) => {
  const frame = useCurrentFrame();
  const draw = useEase(tip.avoidAt, tip.avoidAt + 14);
  const stamp = interpolate(frame, [tip.avoidAt + 10, tip.avoidAt + 24], [0, 1], {
    ...clamp,
    easing: theme.ease.out,
  });
  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <Icon name={`a-${tip.key}`} size={size} color={theme.colors.text} progress={draw} stroke={3.2} />
      <Prohibit size={size} progress={stamp} />
    </div>
  );
};

// লেআউট ক: কেন্দ্রে মেডালিয়ন, নিচে সমস্যার নাম ও এড়ানোর কার্ড
const LayoutHero: React.FC<P> = ({ tip }) => {
  const pIcon = useSpring(0, theme.spring.pop);
  const pName = useSpring(5, theme.spring.snappy);
  const pAvoid = useSpring(tip.avoidAt, theme.spring.pop);
  const draw = useEase(2, 26);
  const float = useFloat(9);
  return (
    <AbsoluteFill style={{ alignItems: "center" }}>
      <div style={{ position: "absolute", top: 340, ...enterStyle(pIcon, 80, float) }}>
        <Medallion size={400}>
          <Icon name={`p-${tip.key}`} size={220} color={theme.colors.accent} progress={draw} glow={theme.colors.accentGlow} />
        </Medallion>
      </div>
      <div
        style={{
          position: "absolute",
          top: 780,
          width: 940,
          textAlign: "center",
          ...problemTextStyle(tip.problem),
          ...enterStyle(pName, 60),
        }}
      >
        {tip.problem}
      </div>
      <div
        style={{
          position: "absolute",
          top: 1050,
          maxWidth: 960,
          display: "flex",
          alignItems: "center",
          gap: 28,
          padding: "26px 48px 26px 30px",
          ...glassCard(),
          borderRadius: theme.radius.pill,
          ...enterStyle(pAvoid, 50),
        }}
      >
        <AvoidBadge tip={tip} size={116} />
        <div style={avoidTextStyle(tip.avoid)}>{tip.avoid}</div>
      </div>
    </AbsoluteFill>
  );
};

// লেআউট খ: ওপরে সমস্যার কার্ড, তির, নিচে এড়ানোর বড় কার্ড
const LayoutSplit: React.FC<P> = ({ tip }) => {
  const pTop = useSpring(0, theme.spring.pop);
  const pBot = useSpring(tip.avoidAt, theme.spring.pop);
  const draw = useEase(2, 26);
  const arrow = useEase(tip.avoidAt - 10, tip.avoidAt + 6);
  const float = useFloat(7, 0.3);
  return (
    <AbsoluteFill style={{ alignItems: "center" }}>
      <div
        style={{
          position: "absolute",
          top: 330,
          width: 920,
          display: "flex",
          alignItems: "center",
          gap: 36,
          padding: "36px 44px",
          ...glassCard(),
          ...enterStyle(pTop, 70, float),
        }}
      >
        <Medallion size={220}>
          <Icon name={`p-${tip.key}`} size={120} color={theme.colors.accent} progress={draw} glow={theme.colors.accentGlow} />
        </Medallion>
        <div style={{ flex: 1, ...problemTextStyle(tip.problem, 120, 440) }}>
          {tip.problem}
        </div>
      </div>
      <svg width={120} height={170} viewBox="0 0 120 170" style={{ position: "absolute", top: 650, overflow: "visible" }}>
        <path
          d="M60 6 V150 M26 118 L60 154 L94 118"
          fill="none"
          stroke={theme.colors.accent}
          strokeWidth={8}
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
          strokeDasharray="1"
          strokeDashoffset={1 - arrow}
          opacity={arrow > 0 ? 1 : 0}
        />
      </svg>
      <div
        style={{
          position: "absolute",
          top: 850,
          width: 920,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 28,
          padding: "44px 40px 48px",
          ...glassCard(),
          ...enterStyle(pBot, 60),
        }}
      >
        <AvoidBadge tip={tip} size={260} />
        <div style={{ ...avoidTextStyle(tip.avoid), textAlign: "center" }}>{tip.avoid}</div>
      </div>
    </AbsoluteFill>
  );
};

// লেআউট গ: রেফারেন্স ধাঁচের লিডার-লাইনসহ হলুদ লেবেল, কেন্দ্রে বড় এড়ানোর মেডালিয়ন
const LayoutCallout: React.FC<P> = ({ tip }) => {
  const pLabel = useSpring(0, theme.spring.snappy);
  const pChip = useSpring(2, theme.spring.pop);
  const pMain = useSpring(tip.avoidAt, theme.spring.pop);
  const leader = useEase(8, 24);
  const draw = useEase(4, 28);
  const float = useFloat(10, 0.32);
  return (
    <AbsoluteFill style={{ alignItems: "center" }}>
      <div
        style={{
          position: "absolute",
          left: 80,
          top: 330,
          display: "flex",
          alignItems: "center",
          gap: 30,
          ...enterStyle(pChip, 60),
        }}
      >
        <Medallion size={190}>
          <Icon name={`p-${tip.key}`} size={104} color={theme.colors.accent} progress={draw} glow={theme.colors.accentGlow} />
        </Medallion>
        <div
          style={{
            width: 700,
            ...problemTextStyle(tip.problem, 120, 700),
            ...enterStyle(pLabel, 40),
            transform: undefined,
          }}
        >
          {tip.problem}
        </div>
      </div>
      <svg width={1080} height={400} viewBox="0 0 1080 400" style={{ position: "absolute", left: 0, top: 560 }}>
        <path
          d="M175 0 V150 L540 150 V240"
          fill="none"
          stroke="rgba(255,255,255,0.75)"
          strokeWidth={2.5}
          pathLength={1}
          strokeDasharray="1"
          strokeDashoffset={1 - leader}
          opacity={leader > 0 ? 1 : 0}
        />
      </svg>
      <div style={{ position: "absolute", top: 800, ...enterStyle(pMain, 90, float) }}>
        <Medallion size={420}>
          <AvoidBadge tip={tip} size={256} />
        </Medallion>
      </div>
      <div
        style={{
          position: "absolute",
          top: 1245,
          width: 940,
          textAlign: "center",
          ...avoidTextStyle(tip.avoid),
          ...enterStyle(pMain, 30),
        }}
      >
        {tip.avoid}
      </div>
    </AbsoluteFill>
  );
};

export const TipScene: React.FC<P> = ({ tip }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const exit = interpolate(frame, [durationInFrames - OVERLAP, durationInFrames], [0, 1], {
    ...clamp,
    easing: theme.ease.in,
  });
  const L = tip.index % 3;
  return (
    <AbsoluteFill style={{ opacity: 1 - exit, transform: `translateY(${-exit * 40}px) scale(${1 - exit * 0.03})` }}>
      {L === 0 ? <LayoutHero tip={tip} /> : L === 1 ? <LayoutSplit tip={tip} /> : <LayoutCallout tip={tip} />}
    </AbsoluteFill>
  );
};
