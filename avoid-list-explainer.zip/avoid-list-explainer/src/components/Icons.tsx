import React from "react";
import { clamp } from "../motion";
import { theme } from "../theme";

type Def = { paths: string[]; transform?: string };

// সব আইকন CSS/SVG দিয়ে আঁকা (viewBox 100x100), লাইন-আর্ট স্টাইল
export const icons: Record<string, Def> = {
  // সমস্যা (অঙ্গ)
  "p-bp": {
    paths: [
      "M50 84 C20 62 10 42 22 26 C32 14 46 19 50 30 C54 19 68 14 78 26 C90 42 80 62 50 84 Z",
      "M16 52 H36 L42 38 L53 64 L59 48 H84",
    ],
  },
  "p-acidity": {
    paths: [
      "M50 10 C58 30 76 38 76 60 C76 77 64 90 50 90 C36 90 24 77 24 60 C24 48 32 44 36 34 C40 42 44 42 46 40 C48 30 46 20 50 10 Z",
      "M50 56 C56 64 62 66 62 74 C62 80 56 84 50 84 C44 84 38 80 38 74 C38 66 46 62 50 56 Z",
    ],
  },
  "p-diabetes": {
    paths: [
      "M50 10 C50 10 22 44 22 62 C22 78 34 90 50 90 C66 90 78 78 78 62 C78 44 50 10 50 10 Z",
      "M36 64 C36 72 42 78 48 79",
    ],
  },
  "p-gout": {
    paths: [
      "M34 42 C34 34 26 30 20 34 C14 38 14 46 20 48 C14 50 14 62 20 66 C26 70 34 66 34 58 H66 C66 66 74 70 80 66 C86 62 86 50 80 48 C86 46 86 38 80 34 C74 30 66 34 66 42 Z",
    ],
    transform: "rotate(-35 50 50)",
  },
  "p-lung": {
    paths: [
      "M44 36 C30 38 16 56 16 76 C16 84 24 86 30 82 C38 78 44 70 44 58 Z",
      "M56 36 C70 38 84 56 84 76 C84 84 76 86 70 82 C62 78 56 70 56 58 Z",
      "M50 12 V46 M50 46 L43 55 M50 46 L57 55",
    ],
  },
  "p-cholesterol": {
    paths: [
      "M8 34 H92 M8 66 H92",
      "M26 34 C28 52 46 52 48 34",
      "M56 66 C58 48 76 48 78 66",
      "M62 40 v0.1 M36 58 v0.1",
    ],
  },
  "p-weight": {
    paths: [
      "M20 22 H80 C84 22 86 24 86 28 V78 C86 82 84 84 80 84 H20 C16 84 14 82 14 78 V28 C14 24 16 22 20 22 Z",
      "M28 50 A22 22 0 0 1 72 50",
      "M50 50 L60 36",
    ],
  },
  "p-tooth": {
    paths: [
      "M30 16 C42 12 46 20 50 20 C54 20 58 12 70 16 C84 22 82 44 74 54 C70 62 72 86 64 86 C58 86 58 70 50 70 C42 70 42 86 36 86 C28 86 30 62 26 54 C18 44 16 22 30 16 Z",
    ],
  },
  "p-sleep": {
    paths: [
      "M58 14 C36 18 22 38 26 60 C30 80 52 92 74 84 C52 78 44 54 54 36 C56 28 58 20 58 14 Z",
      "M66 16 H82 L66 34 H82",
    ],
  },
  "p-kidney": {
    paths: [
      "M60 14 C84 16 92 44 80 62 C72 74 62 84 46 84 C30 84 20 70 26 58 C30 50 42 52 44 44 C46 34 38 22 60 14 Z",
      "M54 50 C64 50 64 64 54 66",
    ],
  },
  "p-eye": {
    paths: [
      "M6 50 C24 24 76 24 94 50 C76 76 24 76 6 50 Z",
      "M36 50 a14 14 0 1 0 28 0 a14 14 0 1 0 -28 0",
      "M45 50 a5 5 0 1 0 10 0 a5 5 0 1 0 -10 0",
    ],
  },
  // এড়ানোর জিনিস
  "a-bp": {
    paths: [
      "M34 40 C34 22 66 22 66 40 Z",
      "M32 40 H68 L74 84 C74 88 70 90 66 90 H34 C30 90 26 88 26 84 Z",
      "M42 31 v0.1 M50 28 v0.1 M58 31 v0.1",
      "M38 12 v0.1 M50 8 v0.1 M62 12 v0.1",
    ],
  },
  "a-acidity": {
    paths: [
      "M62 26 C86 28 88 64 56 86 C40 96 22 92 16 84 C36 82 52 70 56 50 C58 40 56 30 62 26 Z",
      "M62 26 C62 18 68 14 76 14",
    ],
  },
  "a-diabetes": {
    paths: [
      "M50 20 L82 36 L50 52 L18 36 Z",
      "M18 36 V66 L50 82 V52",
      "M82 36 V66 L50 82",
    ],
  },
  "a-gout": {
    paths: [
      "M24 32 C38 14 72 16 82 34 C92 52 76 84 52 86 C30 88 12 70 16 52 C18 44 18 38 24 32 Z",
      "M36 52 a14 12 0 1 0 28 0 a14 12 0 1 0 -28 0",
    ],
  },
  "a-lung": {
    paths: [
      "M10 62 H68 V78 H10 Z",
      "M52 62 V78",
      "M76 68 C88 58 72 50 84 40 C92 32 84 24 88 16",
      "M76 76 H80",
    ],
  },
  "a-cholesterol": {
    paths: [
      "M12 52 L44 36 L88 48 L56 66 Z",
      "M12 52 V70 L56 86 V66",
      "M88 48 V66 L56 86",
      "M64 48 C72 42 78 48 72 54",
    ],
  },
  "a-weight": {
    paths: [
      "M16 46 C16 22 84 22 84 46 Z",
      "M14 56 q6 6 12 0 t12 0 t12 0 t12 0 t12 0",
      "M18 66 H82 C82 80 74 84 66 84 H34 C26 84 18 80 18 66 Z",
      "M36 34 v0.1 M50 30 v0.1 M64 34 v0.1",
    ],
  },
  "a-tooth": {
    paths: [
      "M34 50 a16 16 0 1 0 32 0 a16 16 0 1 0 -32 0",
      "M34 50 L12 38 V62 Z",
      "M66 50 L88 38 V62 Z",
      "M42 44 C48 40 56 46 58 52",
    ],
  },
  "a-sleep": {
    paths: [
      "M18 40 H70 V62 C70 76 60 86 44 86 C28 86 18 76 18 62 Z",
      "M70 46 C88 46 88 68 68 68",
      "M32 30 C26 22 38 18 32 10 M48 30 C42 22 54 18 48 10",
    ],
  },
  "a-kidney": {
    paths: [
      "M32 26 H68 V80 C68 86 60 90 50 90 C40 90 32 86 32 80 Z",
      "M32 26 C32 18 68 18 68 26",
      "M32 52 C42 44 58 60 68 52",
      "M58 18 L66 6 H76",
      "M82 44 a3 3 0 1 0 0.1 0",
    ],
  },
  "a-eye": {
    paths: [
      "M32 10 H68 C72 10 74 12 74 16 V84 C74 88 72 90 68 90 H32 C28 90 26 88 26 84 V16 C26 12 28 10 32 10 Z",
      "M32 22 H68 V74 H32 Z",
      "M46 82 H54",
      "M82 38 C88 44 88 56 82 62",
    ],
  },
};

export const Icon: React.FC<{
  name: string;
  size: number;
  color: string;
  progress?: number;
  stroke?: number;
  glow?: string;
}> = ({ name, size, color, progress = 1, stroke = 3.6, glow }) => {
  const def = icons[name];
  const p = Math.min(1, Math.max(0, progress));
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      style={{
        overflow: "visible",
        opacity: p <= 0 ? 0 : 1,
        filter: glow ? `drop-shadow(0 0 ${size * 0.07}px ${glow})` : undefined,
      }}
    >
      <g transform={def.transform}>
        {def.paths.map((d, i) => (
          <path
            key={i}
            d={d}
            pathLength={1}
            stroke={color}
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="1"
            strokeDashoffset={1 - p}
          />
        ))}
      </g>
    </svg>
  );
};

// নিষেধের রিং + তির্যক দাগ
export const Prohibit: React.FC<{ size: number; progress: number }> = ({ size, progress }) => {
  const ring = Math.min(1, Math.max(0, progress / 0.6));
  const slash = Math.min(1, Math.max(0, (progress - 0.35) / 0.65));
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      style={{
        position: "absolute",
        left: 0,
        top: 0,
        overflow: "visible",
        filter: `drop-shadow(0 0 ${size * 0.05}px ${theme.colors.accentGlow})`,
      }}
    >
      <path
        d="M50 5 a45 45 0 1 1 0 90 a45 45 0 1 1 0 -90"
        pathLength={1}
        stroke={theme.colors.accent}
        strokeWidth={5}
        strokeLinecap="round"
        strokeDasharray="1"
        strokeDashoffset={1 - ring}
        opacity={ring > 0 ? 1 : 0}
      />
      <path
        d="M18 18 L82 82"
        pathLength={1}
        stroke={theme.colors.accent}
        strokeWidth={6}
        strokeLinecap="round"
        strokeDasharray="1"
        strokeDashoffset={1 - slash}
        opacity={slash > 0 ? 1 : 0}
      />
    </svg>
  );
};

export { clamp };
