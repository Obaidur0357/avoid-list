import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";

const grain =
  "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.55 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")";

// কালার গ্রেড + গ্রেইন + ভিনিয়েট (সবার ওপরে, ক্যাপশনের নিচে)
export const Finish: React.FC = () => {
  const frame = useCurrentFrame();
  const jitter = (frame % 4) * 37;
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <AbsoluteFill
        style={{ background: "linear-gradient(180deg, rgba(255,120,60,0.05) 0%, rgba(0,0,0,0.22) 100%)" }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: grain,
          backgroundPosition: `${jitter}px ${jitter * 0.6}px`,
          opacity: 0.1,
          mixBlendMode: "overlay",
        }}
      />
      <AbsoluteFill
        style={{ background: "radial-gradient(ellipse at 50% 50%, transparent 52%, rgba(0,0,0,0.62) 100%)" }}
      />
    </AbsoluteFill>
  );
};
