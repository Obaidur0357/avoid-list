import React from "react";
import { useCurrentFrame } from "remotion";
import { useSpring } from "../motion";
import { FPS, words } from "../script";
import { theme } from "../theme";

const startF = (i: number) => Math.round(words[i].start * FPS);
const endF = (i: number) => Math.round(words[i].end * FPS);

// এক সময়ে একটি শব্দ, রেফারেন্স ভিডিওর ক্যাপশন ধাঁচে
export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  let active = -1;
  for (let i = words.length - 1; i >= 0; i--) {
    if (frame >= startF(i) - 2 && frame < endF(i) + 4) {
      active = i;
      break;
    }
  }
  if (active < 0) return null;
  return <Word index={active} key={active} />;
};

const Word: React.FC<{ index: number }> = ({ index }) => {
  const p = useSpring(startF(index) - 2, theme.spring.snappy);
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top: theme.layout.captionY,
        display: "flex",
        justifyContent: "center",
        opacity: Math.min(1, p * 2),
        transform: `scale(${0.8 + 0.2 * p})`,
      }}
    >
      <span
        style={{
          fontFamily: theme.fonts.display,
          fontWeight: 800,
          fontSize: 104,
          lineHeight: 1,
          textTransform: "uppercase",
          color: theme.colors.text,
          WebkitTextStroke: "14px #000",
          paintOrder: "stroke fill",
          textShadow: "0 8px 0 rgba(0,0,0,0.85)",
        }}
      >
        {words[index].text}
      </span>
    </div>
  );
};
