import React from "react";
import { AbsoluteFill, random, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

const PARTICLES = 16;

export const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;
  const c = theme.colors;
  return (
    <AbsoluteFill style={{ background: c.bg }}>
      <AbsoluteFill
        style={{
          background: `radial-gradient(900px 900px at ${78 + Math.sin(t * 0.4) * 6}% ${22 + Math.cos(t * 0.3) * 4}%, rgba(255,138,91,0.30), transparent 70%),
            radial-gradient(1100px 1100px at ${14 + Math.cos(t * 0.35) * 6}% ${82 + Math.sin(t * 0.3) * 4}%, rgba(150,40,15,0.45), transparent 72%),
            radial-gradient(700px 700px at 50% 48%, ${c.bgWarm}, transparent 75%)`,
        }}
      />
      {Array.from({ length: PARTICLES }).map((_, i) => {
        const size = 24 + random(`s-${i}`) * 70;
        const x = random(`x-${i}`) * width;
        const speed = 14 + random(`v-${i}`) * 26;
        const y0 = random(`y-${i}`) * (height + 200);
        const y = ((y0 - t * speed) % (height + 200) + (height + 200)) % (height + 200) - 100;
        const sway = Math.sin(t * 0.6 + i) * 18;
        const alpha = 0.08 + random(`a-${i}`) * 0.16;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x + sway,
              top: y,
              width: size,
              height: size,
              borderRadius: "50%",
              background: `radial-gradient(circle, rgba(255,205,140,${alpha * 1.6}), rgba(255,170,90,${alpha * 0.4}) 55%, transparent 72%)`,
              filter: `blur(${4 + random(`b-${i}`) * 8}px)`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};
