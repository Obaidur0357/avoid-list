import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";

// কাচের মতো গোল মেডালিয়ন, ধীরে ঘোরা ডটেড রিংসহ
export const Medallion: React.FC<{ size: number; children: React.ReactNode }> = ({ size, children }) => {
  const frame = useCurrentFrame();
  const c = theme.colors;
  return (
    <div
      style={{
        position: "relative",
        width: size,
        height: size,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: `radial-gradient(circle at 35% 28%, ${c.glassTop}, ${c.glassBottom} 70%)`,
        border: `2px solid ${c.glassBorder}`,
        boxShadow: `0 0 ${size * 0.22}px ${c.accentGlow}, inset 0 0 ${size * 0.12}px rgba(255,255,255,0.05)`,
      }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        style={{ position: "absolute", left: 0, top: 0, transform: `rotate(${frame * 0.35}deg)` }}
      >
        <circle cx="50" cy="50" r="47" fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth="0.5" strokeDasharray="1.2 2.6" />
      </svg>
      {children}
    </div>
  );
};

export const glassCard = (): React.CSSProperties => ({
  background: `linear-gradient(160deg, ${theme.colors.glassTop}, ${theme.colors.glassBottom})`,
  border: `2px solid ${theme.colors.glassBorder}`,
  borderRadius: theme.radius.card,
  boxShadow: `0 24px 80px rgba(0,0,0,0.45), 0 0 60px ${theme.colors.accentGlow}`,
});

// সবচেয়ে লম্বা শব্দ বক্সে আঁটবে এমন ফন্ট সাইজ (boxWidth px-এর ভেতর)
export const problemSize = (text: string, base: number, boxWidth: number): number => {
  const longest = Math.max(...text.split(" ").map((w) => w.length));
  return Math.floor(Math.min(base, boxWidth / (longest * 0.62)));
};

export const problemTextStyle = (text: string, base = 140, boxWidth = 940): React.CSSProperties => ({
  fontFamily: theme.fonts.display,
  fontWeight: 800,
  fontSize: problemSize(text, text.length > 14 ? base - 20 : base, boxWidth),
  lineHeight: 0.95,
  textTransform: "uppercase",
  color: theme.colors.hero,
  textShadow: "0 0 36px rgba(255,210,31,0.35)",
});

export const avoidTextStyle = (text: string): React.CSSProperties => ({
  fontFamily: theme.fonts.display,
  fontWeight: 700,
  fontSize: text.length > 16 ? 72 : 88,
  lineHeight: 1,
  textTransform: "uppercase",
  color: theme.colors.text,
});
