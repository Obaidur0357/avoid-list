import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { Background } from "./components/Background";
import { Captions } from "./components/Captions";
import { Finish } from "./components/Finish";
import { Header } from "./components/Header";
import { PreviewAudio } from "./components/PreviewAudio";
import { Recap } from "./components/Recap";
import { Sfx } from "./components/Sfx";
import { TipScene } from "./components/TipScene";
import { RECAP_START, TOTAL_FRAMES, tips } from "./script";
import { theme } from "./theme";

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg }}>
    <Background />
    {tips.map((tip) => (
      <Sequence key={tip.key} from={tip.start} durationInFrames={tip.duration} name={tip.problem}>
        <TipScene tip={tip} />
      </Sequence>
    ))}
    <Sequence from={RECAP_START} durationInFrames={TOTAL_FRAMES - RECAP_START} name="Recap">
      <Recap />
    </Sequence>
    <Finish />
    <Header />
    <Captions />
    <Sfx />
    <PreviewAudio />
  </AbsoluteFill>
);
